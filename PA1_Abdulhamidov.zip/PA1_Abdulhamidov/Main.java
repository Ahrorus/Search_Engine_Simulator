// Ahror Abdulhamidov
// This is the Main class

package sample;

public class Main {

    public static void main(String[] args) {
        GUIForm form = new GUIForm();
        form.launch();  // Launches the GUI application
    }

}
